﻿'
' Created by SharpDevelop.
' User: Admin
' Date: 29.06.2011
' Time: 16:03
'
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Public Partial Class MainForm
	
	Protected strPathA As String
	
	#Region "Конструктор"
	
	Public Sub New()
				
		
		If my.Application.CommandLineArgs.Count > 0 Then
			Call prCommandLineObr(my.Application.CommandLineArgs)
			END
		End If
		
		Me.InitializeComponent()
		
		
					
	End Sub
	
	#End Region
	
	#Region "Работа из коммандной строки"
	
	Sub prCommandLineObr(objRC as system.Collections.ObjectModel.ReadOnlyCollection(Of String))
		
		'Минимальная коммандная строка - путь к файлу БД
		'или (можно по одному)
		'Путь к файлу БД, Путь к файлу для сохранения (csv) / разделитель /добавлять названия полей (0,1,2,3)
				
		Dim strPathToDb As String
		Dim strPathToCsv As String = Nothing
		Dim strDelemiter as String = Nothing
		Dim bytAddTitle As Byte = 2
		
		For intFor As Integer = 0 To objRc.Count -1
			
			Select Case intFor
				Case 0 'Первый аргумент - путь к БД
					strPathToDb = objRc.Item(intFor)
				Case 1 'Второй - путь к CSV
					if objRc.Item(intFor).Trim <> "" then strPathToCsv = objRc.Item(intFor)
				Case 2 'Третий - разделитель
					if objRc.Item(intFor) <> "" then strDelemiter = objRc.Item(intFor)
				Case 3 'Четвертый - от 0 до 4 - заголовки полей
					If IsNumeric(objRc.Item(intFor)) = True AndAlso (objRc.Item(intFor) >= 0 AndAlso objRc.Item(intFor) <=4) Then
						bytAddTitle = objRc.Item(intFor)
					End If
			End Select
			
		Next
						
		Dim lstFilterOrder As New List(Of String)
		Dim lstAlias As New List(Of String)
		Dim strNameSort As String
		
		Call prLoadIni(lstFilterOrder,lstAlias,strNameSort)
		Call prObr(strPathToDb,strPathToCsv,strDelemiter,bytAddTitle,lstFilterOrder,lstAlias,strNameSort)
		
	End Sub
	
	''' <summary>
	''' Процедуре заполняет параметры, переданные по ссылке (ByRef)
	''' </summary>
	''' <param name="strFilterOrder">Массив для заполнения - какие поля брать из БД</param>
	''' <param name="strAlias">Массив для соспоставление имен полей (как БД - пользовательское)</param>
	''' <param name="strNameSort">Переменная для заполнения - имя поля для сортировки</param>
	Sub prLoadIni(ByRef lstFilterOrder as List(Of String), ByRef lstAlias as List(Of String),ByRef strNameSort as String)
		
		'Если нет файла с Filter.ini (параметры фильтрации полей в БД, сопоставление имен полей и указание сортировки) - то выход
		If io.File.Exists(application.StartupPath &"\Filter.ini") = False Then Exit Sub
				
		Dim strTxt() As String
		Dim z as String = application.StartupPath &"\Filter.ini"
		Dim i As Integer = FreeFile
		
		strTxt = Split(my.Computer.FileSystem.ReadAllText(application.StartupPath &"\Filter.ini",system.Text.Encoding.GetEncoding(1251)),vbcrlf)
						
		Dim strS() As String
		Dim lstFO as New List(Of String)
		Dim lstA as New List(Of String)
		Dim strSort as String = Nothing
		
		For intFor As Integer = 0 To ubound(strTxt)
			
			strS = Split(strTxt(intFor),",")
			
			If ubound(strS) = 1 Then
				lstFO.Add(strS(0))
				lstA.Add(strS(1))
			Elseif ubound(strS) = 2 Then
				lstFO.Add(strS(0))
				lstA.Add(strS(1))
				strSort = strS(0)
			End If
						
		Next
		
		lstFilterOrder = lstFO
		lstAlias = lstA
		strNameSort = strSort
		
	End Sub
	
	#End Region
		
	#Region "Обработка"
	
	''' <summary>
	''' Выполнить обработку
	''' </summary>
	''' <param name="strFobr">Путь к файлу обработки</param>
	''' <param name="strFsave">Путь к файлу сохранения (или Nothing - если файл с тем же именем, в ту же папку, только расширение - csv)</param>
	''' <param name="strDelimiter">Разделитель полей в файле csv(или Nohtin - если точка с запятой)</param>
	''' <param name="bytTitle">Заголовки (имена колонок) (0-нет,1-в файле,2-shema.ini, 3 - и в файл и shema.ini)</param>
	''' <param name="strFilterOrder">Список (он же фильтр) полей (+в таком же порядке выводить их в файл) - если Nothing - то как в БД</param>
	''' <param name="strAlias">Список заголовок полей (если intTitle - не 0). Сопоставление. Например: (0) в БД "col1" а в файл выводить как "Имя" (или Nothing, тогда как в БД)</param>
	''' <param name="strSort">Сортировка по полю (имя поля) или Nohting - если без)</param>
	Sub prObr(strFobr As String,strFsave As String,strDelimiter as String,bytTitle As Byte,lstFilterOrder as List(Of String),lstAlias as List(Of String),strSort as String)
		
		Dim objF As New IO.FileInfo(strFobr)
		Dim strFileSaveName As String
		Dim strSchemaName As String
		
		'UNDONE: Добавить сообщение о том, что файл БД отстуствует
		If objF.Exists = False Then Exit Sub
		
		If strDelimiter = Nothing Then strDelimiter = ";"
		
		'UNDONE: Добавить проверку путей для создания файла CSV
		If strFsave = Nothing Then strFsave = objF.DirectoryName & "\" & Replace(objF.Name,objF.Extension,".csv")
		Dim objFS As New IO.FileInfo(strFsave)
		
		strFileSaveName = objFS.Name
		strSchemaName = objFS.DirectoryName & "\" & "Schema.ini"
		
				
		Dim strT as String = Replace(objF.Name,objF.Extension,"")
		Dim strD as String = objF.DirectoryName & "\"
				
		Dim objT As New ParadoxReader.ParadoxTable(strD,strT)
		
		'Если не заполнен список фильтров (полей, которые надо набирать из БД) - заполнить его из БД (все поля туды добавить
		'+ в список сопоставления имен полей БД-пользовательские - везед пихнуть имена как в БД)
		If lstFilterOrder.Count = 0 Then
			
			For intFor As Integer = 0 To objT.FieldCount -1
				lstFilterOrder.Add(objT.FieldNames(intFor))
				lstAlias.Add(objT.FieldNames(intFor))
			Next
			
		End If
		
		Dim objSB as New System.Text.StringBuilder
		
		'Если без сортировки, то...
		If strSort = Nothing Then
		
			For Each objRec As ParadoxReader.ParadoxRecord In objT.Enumerate()
									
				For i As Integer = 0 To objT.FieldCount - 1
					
					On Error Resume Next
					
					If i = 0 AndAlso lstFilterOrder.Contains(objT.FieldNames(i)) = True Then
						objSB.Append(objRec.DataValues(i))
					ElseIf  i > 0 AndAlso lstFilterOrder.Contains(objT.FieldNames(i)) = True Then
						objSB.Append(strDelimiter & objRec.DataValues(i))
					End If
							
					On Error GoTo 0
									
				Next
				
				objSB.Append(vbcrlf)
										
			Next
		
		'Если с сортировкой, то...
		Else
			
			Dim objFieldSort(0) As Object
			Dim strFullStr(0) As String
			Dim strFS As String = Nothing
			Dim objZn As Object = Nothing
			Dim blnFirstRow As Boolean = True
			
			For Each objRec As ParadoxReader.ParadoxRecord In objT.Enumerate()
									
				For i As Integer = 0 To objT.FieldCount - 1
					
					On Error Resume Next
					
					If i = 0 AndAlso lstFilterOrder.Contains(objT.FieldNames(i)) = True Then
						
						strFS = objRec.DataValues(i)
						if objT.FieldNames(i) = strSort then objZn =  objRec.DataValues(i)
						
					ElseIf  i > 0 AndAlso lstFilterOrder.Contains(objT.FieldNames(i)) = True Then
						
						strFS = strFS & strDelimiter & objRec.DataValues(i)
						if objT.FieldNames(i) = strSort then objZn =  objRec.DataValues(i)
						
					End If
							
					On Error GoTo 0
									
				Next
				
				If blnFirstRow = True Then
					objFieldSort(0) = objZn
					strFullStr(0) = strFS
					blnFirstRow = False
				Else
					ReDim Preserve objFieldSort(ubound(objFieldSort) + 1)
					ReDim Preserve strFullStr(ubound(strFullStr) + 1)
					
					objFieldSort(ubound(objFieldSort)) = objZn
					strFullStr(ubound(strFullStr)) = strFS
					
				End If
										
			Next
			
			Call prShellSort(objFieldSort,strFullStr)
			
			For intFor As Integer = 0 To ubound(strFullStr)
				If intFor <> ubound(strFullStr) Then
					objSB.Append(strFullStr(intFor) & vbcrlf)
				Else
					objSB.Append(strFullStr(intFor))
				End If
				
			Next
			
		End If
		
		Dim strTitle As String = Nothing
		Dim lstSchma As New List(Of String)
		
		If bytTitle > 0 Then
			
			lstSchma.Add("[" & strFileSaveName  & "]" & vbcrlf)
			
			If bytTitle = 3 Then
				lstSchma.Add("ColNameHeader=True" & vbcrlf)
			Else
				lstSchma.Add("ColNameHeader=False" & vbcrlf)
			End If
			
			lstSchma.Add("Format=Delimited(" & strDelimiter & ")" & vbcrlf)
			lstSchma.Add("MaxScanRows=5" & vbcrlf)
			lstSchma.Add("CharacterSet=ANSI" & vbcrlf)
						
			For intFor As Integer = 0 To objT.FieldCount -1
				
				If intFor = 0 AndAlso lstFilterOrder.Contains(objT.FieldNames(intFor)) = True Then
					
					strTitle = lstAlias.Item(lstFilterOrder.IndexOf(objT.FieldNames(intFor)))
					lstSchma.Add("Col" & lstFilterOrder.IndexOf(objT.FieldNames(intFor))+ 1 & "="  & lstAlias.Item(lstFilterOrder.IndexOf(objT.FieldNames(intFor))) & vbcrlf)
					
				ElseIf  intFor > 0 AndAlso lstFilterOrder.Contains(objT.FieldNames(intFor)) = True Then
					
					strTitle = strTitle & strDelimiter & lstAlias.Item(lstFilterOrder.IndexOf(objT.FieldNames(intFor)))
					lstSchma.Add("Col" & lstFilterOrder.IndexOf(objT.FieldNames(intFor)) + 1 & "="  & lstAlias.Item(lstFilterOrder.IndexOf(objT.FieldNames(intFor))) & vbcrlf)
										
				End If
								
								
			Next
			
		End If
		
		'Format=Delimited(;)
		'MaxScanRows=5
		'CharacterSet=ANSI
		'Col1=Дата_время Date
		'Col2=Файл Text
			
		
		objT.Dispose
				
		Dim objW As New IO.StreamWriter(strFsave,False,system.Text.Encoding.GetEncoding(1251))
		
		If bytTitle = 1 Or bytTitle = 3 Then objW.Write(strTitle & vbcrlf)
				
		objW.Write(objSB.ToString)
		
		objW.Close
		objW.Dispose
		
		If bytTitle = 2 Or bytTitle = 3 Then 
			objW = New IO.StreamWriter(strSchemaName,False,system.Text.Encoding.GetEncoding(1251))
			objW.Write(Join(lstSchma.ToArray,Nothing))
			objW.Close
			objW.Dispose			
		End If
		
		
			
		
	End Sub
	
	''' <summary>
	''' Сортировка методом Шелла
	''' </summary>
	''' <param name="arr"></param>
	''' <param name="arrDop"></param>
	Sub prShellSort(byRef arr() as Object, ByRef arrDop() as String)
	  
	  Dim TempVal As Object
	  Dim TempValDop As String
	  
	  Dim i As Long
	  Dim GapSize As Long
	  Dim CurPos As Long
	  
	  Dim FirstRow As Long
	  Dim LastRow As Long
	  Dim NumRows As Long
	  
	  FirstRow = LBound(arr)
	  LastRow = UBound(arr)
	  NumRows = LastRow - FirstRow + 1
	  
	  Do
	    
	    GapSize = GapSize * 3 + 1
	    
	  Loop Until GapSize > NumRows
	  
	  Do
	      GapSize = GapSize \ 3
	     
	     For i = (GapSize + FirstRow) To LastRow
	       
	       CurPos = i
	       TempVal = arr(i)
	       TempValDop = arrDop(i)
	       
	       Do While arr(CurPos - GapSize) > TempVal
	         arr(CurPos) = arr(CurPos - GapSize)
	         arrDop(CurPos) = arrDop(CurPos - GapSize)
	         CurPos = CurPos - GapSize
	         If (CurPos - GapSize) < FirstRow Then Exit Do
	       Loop
	       
	       arr(CurPos) = TempVal
	       arrDop(CurPos) = TempValDop
	       
	     Next
	     
	   Loop Until GapSize = 1
	   
   End Sub
	
	#End Region
	
End Class
